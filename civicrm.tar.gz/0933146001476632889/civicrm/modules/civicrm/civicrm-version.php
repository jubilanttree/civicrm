<?php
function civicrmVersion( ) {
  return array( 'version'  => '4.7.12',
                'cms'      => 'Drupal',
                'revision' => '13f762676e' );
}

